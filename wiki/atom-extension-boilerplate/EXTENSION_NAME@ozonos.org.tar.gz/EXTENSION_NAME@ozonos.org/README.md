Atom Extension
=========
Description

![initial version screenshot](add image url)

### Compatibility

### Compatibility

| Gnome | Compatible |
| :---: | :---: |
| 3.10 | ??? |
| 3.12 | ??? |
| 3.14 | ??? |
| 3.16 | ??? |

### Installation

To install this extension, run the following commands in your Terminal:

```bash
git clone https://github.com/ozonos/REPO_NAME.git
cd REPO_NAME
make
make install
```

### License

This project is licensed with GPL version 3 and later. See LICENSE for more details.

### Changelog

- 0.1 - Initial Release
